CREATE DATABASE iticket;
use iticket;

CREATE TABLE locales (
  id int(11) NOT NULL AUTO_INCREMENT,
  local varchar(50) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO locales VALUES (1,'Cartago'),(2,'Heredia'),(3,'Alajuela'),(4,'Limon'),(5,'San Jose');

CREATE TABLE conciertos (
  id int NOT NULL AUTO_INCREMENT,
  nombre varchar(60) NOT NULL,
  costo int NOT NULL,
  fecha varchar(60) NOT NULL,
  capacidadd varchar(60) NOT NULL,
  PRIMARY KEY (id),
  KEY fk_conciertos_locales_idx (locales_id),
 CONSTRAINT fk_conciertos_locales FOREIGN KEY (locales_id) REFERENCES locales (id) ON DELETE NO ACTION ON UPDATE NO ACTION

) ;

INSERT INTO verduras VALUES (juan,'5000','5 marzo','162500',1);
INSERT INTO verduras VALUES (pedro,'8000','30 junio','17500',3);
INSERT INTO verduras VALUES (maluma,'9000','20 abril','8500',5);
